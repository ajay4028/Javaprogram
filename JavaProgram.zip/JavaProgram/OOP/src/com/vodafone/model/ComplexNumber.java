package com.vodafone.model;

public class ComplexNumber {
	
	private double realPart;
	private double imaginaryPart;
	
	public void setRealPart(double real) {
		realPart = real;
	}
	
	public void setImaginaryPart(double imag) {
		imaginaryPart = imag;
	}
	
	public double getRealPart() {
		return realPart;
	}

	public double getImaginaryPart() {
		return imaginaryPart;
	}
}
