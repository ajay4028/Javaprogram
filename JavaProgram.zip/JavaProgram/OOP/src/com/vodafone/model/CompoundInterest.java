package com.vodafone.model;

public class CompoundInterest implements CalculateInterest {

	@Override
	public double getInterest() {
		
		return 2000.0;
	}

}
