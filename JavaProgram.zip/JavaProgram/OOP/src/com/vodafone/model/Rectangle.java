package com.vodafone.model;

public class Rectangle extends Shape {
	
	public Rectangle() {
		super();
		
	}
	public Rectangle(double firstDimension, double secondDimension) {
		
		super(firstDimension,secondDimension);
	}

	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		return firstDimension * secondDimension;
	}


}
