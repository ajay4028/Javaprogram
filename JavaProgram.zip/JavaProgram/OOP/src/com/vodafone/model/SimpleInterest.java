package com.vodafone.model;

public class SimpleInterest implements CalculateInterest {

	@Override
	public double getInterest() {
		
		return 1200.0;
	}

}
