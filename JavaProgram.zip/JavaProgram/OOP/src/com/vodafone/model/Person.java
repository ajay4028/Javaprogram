package com.vodafone.model;

public class Person {
	private String name;
	private int age;
	
	public Person() {
		/* Default constructor */
	}
	
	public Person(String name,int age)
	{
		this.name =name;
		this.age=age;
	}
	public void show() {
		System.out.print("Name :- " + name +"\t" +"Age :- " + age);
	}
}
