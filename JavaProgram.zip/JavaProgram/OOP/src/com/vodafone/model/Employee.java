package com.vodafone.model;

public class Employee extends Person {
	private double salary;
	
	public Employee() {
		super();
	}
	
	public Employee(String name,int age,double salary) {
		super(name,age);
		this.salary =salary;
	}
	@Override
	public void show()
	{
		super.show();
		System.out.println("Salary =" + "\t" + salary );
	}
}
