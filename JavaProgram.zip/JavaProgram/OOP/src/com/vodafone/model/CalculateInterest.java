package com.vodafone.model;

public interface CalculateInterest {
	double getInterest();
}
