package com.vodafone.ui;

import com.vodafone.model.Employee;
import com.vodafone.model.Person;
import com.vodafone.model.Student;

public class InheritanceApp {

	public static void main(String[] args) {
		Person person=new Person("ajay",22);
		person.show();
		System.out.println();
		
		Employee employee= new Employee("raj",23,50000.0);
		employee.show();
		System.out.println();
		
		Student student = new Student("rohit",17,40000.0);
		student.show();
		System.out.println();
	}

}
