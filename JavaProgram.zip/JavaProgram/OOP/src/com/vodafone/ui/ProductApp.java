package com.vodafone.ui;

import com.vodafone.model.Product;

public class ProductApp {

	public static void main(String[] args) {
		
		Product.setTax(23);
		
		Product first=new Product(1,"mouse",400.0);
		first.show();
		Product second=new Product(2,"RAM",800.0);
		second.show();
		Product third=new Product(3,"monitor",4000.0);
		third.show();
		Product fourth=new Product(4,"keyboard",750.0);
		fourth.show();
		Product fifth=new Product(5,"web cam",1200.0);
		fifth.show();

	}

}
