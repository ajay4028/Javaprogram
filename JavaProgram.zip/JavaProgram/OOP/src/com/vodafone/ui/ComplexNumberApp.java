package com.vodafone.ui;

import com.vodafone.model.ComplexNumber;

public class ComplexNumberApp {

	public static void main(String[] args) {
			ComplexNumber first;
			first =new ComplexNumber();
			
			first.setRealPart(6);
			first.setImaginaryPart(7);
			
			System.out.println(first.getRealPart() + " , " + first.getImaginaryPart());

	}

}
