package com.vodafone.ui;

public class App1 {

	public static void main(String[] args) {
		int []arr = {10,20,45};
		
		try {
			for(int i=0;i<=3;i++) {
				System.out.println(arr[i]);
			}
		}
			catch(ArrayIndexOutOfBoundsException e) {
				System.out.println("over");
			}
		}
	
}

