package com.vodafone.ui;

import com.vodafone.model.Account;

public class AccountApp {

	public static void main(String[] args) {
		Account first =new Account(125,"Ajay",40000.0);
		
		first.deposit(5000);
		System.out.println(first.getBalance());
		
		first.withdraw(50000);
		System.out.println(first.getBalance());
	}

}
