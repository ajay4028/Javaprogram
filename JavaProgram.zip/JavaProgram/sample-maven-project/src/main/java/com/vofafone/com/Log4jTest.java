package com.vofafone.com;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

public class Log4jTest {
	
	private static Logger log = Logger.getLogger(Log4jTest.class);
	
	public static void main(String[] args) {
		
		BasicConfigurator.configure();
		
		log.debug("it is a debug message");
		log.info("it is info message");
	}

}
