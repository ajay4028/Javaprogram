package com.vodafone.ui;

import java.util.Iterator;
import java.util.LinkedList;

public class ListDemo {

	public static void main(String[] args) {
		LinkedList<Integer> list=new LinkedList<>();
		list.add(23);
		list.add(53);
		list.add(20);
		list.add(46);
		list.add(99);
		
		System.out.println(list);
		System.out.println("-------------------------------------------------------");
		
		for(int index=0;index<list.size();index++) {
			System.out.println(list.get(index));
	}
		System.out.println("-------------------------------------------------------");
		
		list.remove(1);
		list.set(2, 77);
		
		for(Integer data : list) {
			System.out.println(data);
		}
		System.out.println("-------------------------------------------------------");
		
		Iterator<Integer> it= list.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("-------------------------------------------------------");
	}
}
