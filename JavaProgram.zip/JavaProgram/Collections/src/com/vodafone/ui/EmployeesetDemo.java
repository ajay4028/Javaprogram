package com.vodafone.ui;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.vodafone.model.Employee;
import com.vodafone.service.NameComparator;

public class EmployeesetDemo {

	public static void main(String[] args) {
		//Set<Employee> emps=new HashSet<>();
		//Set<Employee> emps=new TreeSet<>();
		Set<Employee> emps=new TreeSet<>(new NameComparator());
		//Set<Employee> emps=new TreeSet<>(new SalaryComparator());
		emps.add(new Employee(100,"pratik",LocalDate.of(2001,Month.AUGUST , 10),45000.0));
		emps.add(new Employee(104,"rahul",LocalDate.of(2003,Month.APRIL, 16),50000.0));
		emps.add(new Employee(107,"rohit",LocalDate.of(2002,Month.FEBRUARY , 23),40000.0));
		emps.add(new Employee(102,"david",LocalDate.of(2004,Month.JULY , 1),60000.0));
		emps.add(new Employee(100,"john",LocalDate.of(2006,Month.SEPTEMBER , 7),35000.0));
		
		for(Employee emp:emps) {
			System.out.println(emp);
		}
		System.out.println("------------------------------------------------------------");
	}

}
