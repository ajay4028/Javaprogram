package com.vodafone.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		
		List<String> names=new ArrayList<>();
		names.add("rohit");
		names.add("david");
		names.add("ajay");
		names.add("rahul");
		names.add("raj");
		
		Collections.sort(names);
		Collections.reverse(names);
		
		for(String name:names) {
			System.out.println(names);
		}
		

	}

}
