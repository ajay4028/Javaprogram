package com.vodafone.ui;

public class ArithmeticOperation {

	public static void main(String[] args) {
		
		int firstNumber=10;
		int secondNumber=40;
		
		int result;
		result = firstNumber + secondNumber;
		System.out.println("Sum:- "+ result);
		result = firstNumber - secondNumber;
		System.out.println("Difference:- "+ result);
		result = firstNumber * secondNumber;
		System.out.println("Product:- "+ result);
		result = firstNumber / secondNumber;
		System.out.println("Quotient:- "+ result);
		result = firstNumber % secondNumber;
		System.out.println("Remainder:- "+ result);

	}
}
